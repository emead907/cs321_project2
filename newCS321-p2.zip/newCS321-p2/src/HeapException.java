
@SuppressWarnings("serial")
public class HeapException extends Exception {

	public HeapException(String s) {
		super(s);
	}
}
